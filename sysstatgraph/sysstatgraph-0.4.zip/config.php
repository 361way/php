<?php
// config.php



define('SYSSTATDATAPATH','/var/log/sa');
define('JSONSTRUCTUREFILENAME','data.json');
define('NETWORKINTERFACELIST',serialize(array('lo')));
// define('NETWORKINTERFACELIST',serialize(array('lo','eth0')));
