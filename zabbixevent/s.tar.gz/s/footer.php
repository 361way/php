

               </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
   <p class="text-center">版权所有 © 2015-2017 咪咕阅读ITO</p>
   <!-- jQuery -->
    <script src="static/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="static/js/bootstrap.min.js"></script>
</body>
</html>
